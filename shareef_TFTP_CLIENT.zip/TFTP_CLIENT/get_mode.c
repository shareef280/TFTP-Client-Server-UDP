#include "CLIENT.h"

int get_mode()
{
    char file_name[50];

    printf("Enter the filename: ");

    if (scanf(" %49[^\n]", file_name) != 1)
    {
        printf("Invalid filename.\n");
        while (getchar() != '\n');
        return FAILURE;
    }

    if (sent_request_pkt(file_name, OPCODE_RRQ, NORMAL) == FAILURE)
    {
        printf("GET request failed. Server is not available.\n");
        return FAILURE;
    }

    if (get_file(file_name, NORMAL) == FAILURE)
    {
        printf("GET operation failed.\n");
        return FAILURE;
    }

    printf("GET operation completed successfully.\n");

    return SUCCESS;
}


Status get_file(char *file_name, int mode)
{
    Data_pkt data_var;
    Ack_pkt ack_var;

    int fd;
    int expected_block = 1;
    int recv_len;
    int data_size;

    struct sockaddr_in server_addr;
    socklen_t len = sizeof(server_addr);

    // Create the destination file for receiving data
    fd = open(file_name, O_WRONLY | O_CREAT | O_TRUNC, 0644);

    if (fd == -1)
    {
        perror("open");
        return FAILURE;
    }

    while (1)
    {
        len = sizeof(server_addr);

        // Receive DATA packet from the server
        recv_len = recvfrom(sock_fd,
                            &data_var,
                            sizeof(data_var),
                            0,
                            (struct sockaddr *)&server_addr,
                            &len);

        if (recv_len < 0)
        {
            perror("recvfrom");
            close(fd);
            return FAILURE;
        }

        // Check for the end packet
        if (ntohs(data_var.opcode) == END)
        {
            printf("File transfer completed.\n");
            break;
        }

        // Validate DATA opcode
        if (ntohs(data_var.opcode) != OPCODE_DATA)
        {
            printf("Invalid DATA packet received.\n");
            close(fd);
            return FAILURE;
        }

        // Verify the expected block number
        if (ntohs(data_var.block_no) != expected_block)
        {
            printf("Unexpected block %d received. Expected block %d.\n",
                   ntohs(data_var.block_no), expected_block);
            continue;
        }

        // Calculate the actual number of received data bytes
        data_size = recv_len -
                    sizeof(data_var.opcode) -
                    sizeof(data_var.block_no);

        // Write received data into the destination file
        if (data_size > 0)
        {
            if (write(fd, data_var.data, data_size) != data_size)
            {
                perror("write");
                close(fd);
                return FAILURE;
            }
        }

        printf("Block %d received (%d bytes).\n",
               expected_block, data_size);

        // Send ACK for the received block
        memset(&ack_var, 0, sizeof(ack_var));

        ack_var.opcode = htons(OPCODE_ACK);
        ack_var.block_no = htons(expected_block);

        if (sendto(sock_fd,
                   &ack_var,
                   sizeof(ack_var),
                   0,
                   (struct sockaddr *)&server_addr,
                   len) < 0)
        {
            perror("sendto");
            close(fd);
            return FAILURE;
        }

        printf("ACK %d sent successfully.\n", expected_block);

        // Normal mode ends when a packet contains less than 512 bytes
        if (mode == NORMAL && data_size < 512)
        {
            break;
        }

        expected_block++;
    }

    close(fd);

    return SUCCESS;
}