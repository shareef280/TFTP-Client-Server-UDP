#include "CLIENT.h"

void netasci_get_mode()
{
    char file_name[50];

    printf("Enter filename: ");
    scanf(" %[^\n]", file_name);

    // Send RRQ request in Netascii mode
    if (sent_request_pkt(file_name, OPCODE_RRQ, NETASCI) == FAILURE)
    {
        printf("Error: Server could not send the file.\n");
        return;
    }

    if (get_file(file_name, NETASCI) == FAILURE)
    {
        printf("Error: GET operation failed.\n");
    }
}

Status netasci_put_mode()
{
    char file_name[50];

    printf("Enter filename: ");
    scanf(" %[^\n]", file_name);

    int fd = open(file_name, O_RDONLY);

    if (fd == -1)
    {
        printf("Error: File '%s' not found.\n", file_name);
        return FAILURE;
    }

    // Send WRQ request in Netascii mode
    if (sent_request_pkt(file_name, OPCODE_WRQ, NETASCI) == FAILURE)
    {
        printf("Error: Server could not receive the file.\n");
        close(fd);
        return FAILURE;
    }

    if (netasci_put_file(file_name, fd, NETASCI) == FAILURE)
    {
        close(fd);
        return FAILURE;
    }

    close(fd);

    return SUCCESS;
}

Status netasci_put_file(char *filename, int fd, int mode)
{
    Data_pkt data_var;
    Ack_pkt ack_var;

    char buffer[512];

    int no = 1;
    int newlineflag = 0;

    struct sockaddr_in server_addr;
    socklen_t len = sizeof(server_addr);

    // Receive ACK 0 after sending WRQ
    int recv_len = recvfrom(sock_fd, &ack_var, sizeof(ack_var), 0,
                            (struct sockaddr *)&server_addr, &len);

    if (recv_len < 0)
    {
        perror("recvfrom");
        return FAILURE;
    }

    // Validate ACK 0
    if (recv_len < sizeof(Ack_pkt) ||
        ntohs(ack_var.opcode) != OPCODE_ACK ||
        ntohs(ack_var.block_no) != 0)
    {
        printf("Error: Invalid ACK 0 received from server.\n");
        return FAILURE;
    }

    printf("ACK 0 received - ready to send file\n");

    while (1)
    {
        int i = 0;
        int eof = 0;

        // Add pending LF from the previous packet
        if (newlineflag == 1)
        {
            buffer[i++] = '\n';
            newlineflag = 0;
        }

        // Read source file and convert LF to CR-LF
        while (i < 512)
        {
            char ch;

            int ret = read(fd, &ch, 1);

            if (ret == 0)
            {
                eof = 1;
                break;
            }

            if (ret < 0)
            {
                perror("read");
                return FAILURE;
            }

            if (ch == '\n')
            {
                // Convert LF to CR-LF
                if (i <= 510)
                {
                    buffer[i++] = '\r';
                    buffer[i++] = '\n';
                }
                else
                {
                    // Store LF for the next packet
                    buffer[i++] = '\r';
                    newlineflag = 1;
                    break;
                }
            }
            else
            {
                buffer[i++] = ch;
            }
        }

        memset(&data_var, 0, sizeof(data_var));

        data_var.opcode = htons(OPCODE_DATA);
        data_var.block_no = htons(no);

        if (i > 0)
        {
            memcpy(data_var.data, buffer, i);
        }

        int pkt_size = sizeof(data_var.opcode) +
                       sizeof(data_var.block_no) +
                       i;

        // Send END packet when the file is completely transmitted
        if (i == 0 && eof && newlineflag == 0)
        {
            data_var.opcode = htons(END);

            if (sendto(sock_fd, &data_var,
                       sizeof(data_var.opcode) + sizeof(data_var.block_no),
                       0, (struct sockaddr *)&server_addr, len) < 0)
            {
                perror("sendto");
                return FAILURE;
            }

            printf("NETASCII PUT: Transfer completed successfully\n");

            return SUCCESS;
        }

    step1:

        // Send DATA packet to the server
        if (sendto(sock_fd, &data_var, pkt_size, 0,
                   (struct sockaddr *)&server_addr, len) < 0)
        {
            perror("sendto");
            return FAILURE;
        }

        printf("Block %d sent to server (%d bytes)\n", no, i);

        // Wait for the corresponding ACK
        recv_len = recvfrom(sock_fd, &ack_var, sizeof(ack_var), 0,
                            (struct sockaddr *)&server_addr, &len);

        if (recv_len < 0)
        {
            perror("recvfrom");
            return FAILURE;
        }

        // Validate the received ACK
        if (recv_len < sizeof(Ack_pkt) ||
            ntohs(ack_var.opcode) != OPCODE_ACK ||
            ntohs(ack_var.block_no) != no)
        {
            printf("Warning: Invalid ACK for block %d, retrying...\n", no);
            goto step1;
        }

        printf("ACK %d received successfully\n", no);

        no++;
    }

    return SUCCESS;
}