
/**
 * Project Title : TFTP (Trivial File Transfer Protocol)
 * Author        : Shareef sab
 * Batch         : 26001B(084)
 * Date          : 12/09/2026
 *
 * Description:
 * This project implements a TFTP client-server application using
 * UDP socket programming. It supports file transfer operations such
 * as GET and PUT with different transfer modes including Normal,
 * Octet, and Netascii modes.
 *
 * The client provides a menu-driven interface to connect to the
 * server, transfer files, select transfer modes, and terminate the
 * connection.
 *
 * The server handles client requests using separate processes and
 * performs file transfer through UDP sockets.
 */



#include "CLIENT.h"

int main()
{
    int option;

    while (1)
    {
        printf("\n========== TFTP CLIENT ==========\n\n");
        printf("1. Connect\n");
        printf("2. Get\n");
        printf("3. Put\n");
        printf("4. Mode\n");
        printf("5. Bye/Quit\n\n");

        printf("Enter your choice: ");

        if (scanf("%d", &option) != 1)
        {
            printf("Error: Please enter a valid option (1-5)\n");

            // Clear invalid input from the input buffer
            while (getchar() != '\n');

            continue;
        }

        switch (option)
        {
            case 1:

                if (connect_server() == FAILURE)
                {
                    printf("Connection failed. Please try again.\n");
                }

                break;

            case 2:

                if (connect_flag == 0)
                {
                    printf("Error: Please connect to the server first.\n");
                    break;
                }

                if (get_mode() == FAILURE)
                {
                    printf("GET operation failed.\n");
                }

                break;

            case 3:

                if (connect_flag == 0)
                {
                    printf("Error: Please connect to the server first.\n");
                    break;
                }

                if (put_mode(NORMAL) == FAILURE)
                {
                    printf("PUT operation failed.\n");
                }

                break;

            case 4:

                if (connect_flag == 0)
                {
                    printf("Error: Please connect to the server first.\n");
                    break;
                }

                mode();

                break;

            case 5:

                printf("Exiting TFTP client. Goodbye!\n");
                return SUCCESS;

            default:

                printf("Error: Invalid choice. Please select 1 to 5.\n");
                break;
        }
    }

    return SUCCESS;
}