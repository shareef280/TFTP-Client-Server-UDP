#include "CLIENT.h"


Status put_mode(int mode)
{
    printf("Enter the filename: ");

    char filename[50];

    if (scanf(" %49[^\n]", filename) != 1)
    {
        printf("Invalid filename.\n");
        while (getchar() != '\n');
        return FAILURE;
    }

    int fd = open(filename, O_RDONLY);

    if (fd == -1)
    {
        printf("File not found or cannot be opened.\n");
        return FAILURE;
    }

    if (sent_request_pkt(filename, OPCODE_WRQ, mode) == FAILURE)
    {
        printf("PUT request failed. Server is not available.\n");
        close(fd);
        return FAILURE;
    }

    if (put_file(filename, fd, mode) == FAILURE)
    {
        printf("PUT operation failed.\n");
        close(fd);
        return FAILURE;
    }

    close(fd);

    printf("PUT operation completed successfully.\n");

    return SUCCESS;
}


Status put_file(char *filename, int fd, int mode)
{
    Data_pkt data_var;
    Ack_pkt ack_var;

    char buffer[512];

    int ret;
    int no = 1;

    struct sockaddr_in client_serv;
    socklen_t len = sizeof(client_serv);

    // Receive ACK 0 after sending WRQ
    int recv_len = recvfrom(sock_fd, &ack_var, sizeof(ack_var), 0,
                            (struct sockaddr *)&client_serv, &len);

    if (recv_len < 0)
    {
        perror("recvfrom");
        return FAILURE;
    }

    // Validate ACK 0
    if (recv_len < sizeof(Ack_pkt) ||
        ntohs(ack_var.opcode) != OPCODE_ACK ||
        ntohs(ack_var.block_no) != 0)
    {
        printf("Invalid ACK 0 received from server.\n");
        return FAILURE;
    }

    printf("ACK 0 received. Starting file transfer.\n");

    while (1)
    {
        // Read 512 bytes in Normal mode and 1 byte in Octet mode
        if (mode == NORMAL)
        {
            ret = read(fd, buffer, 512);
        }
        else if (mode == OCTATE)
        {
            ret = read(fd, buffer, 1);
        }
        else
        {
            printf("Invalid transfer mode.\n");
            return FAILURE;
        }

        if (ret < 0)
        {
            perror("read");
            return FAILURE;
        }

        // Prepare DATA packet
        memset(&data_var, 0, sizeof(data_var));

        data_var.opcode = htons(OPCODE_DATA);
        data_var.block_no = htons(no);

        if (ret > 0)
        {
            memcpy(data_var.data, buffer, ret);
        }

        // Send END packet after all file data is transmitted
        if (ret == 0)
        {
            data_var.opcode = htons(END);

            int pkt_size = sizeof(data_var.opcode) +
                           sizeof(data_var.block_no);

            if (sendto(sock_fd, &data_var, pkt_size, 0,
                       (struct sockaddr *)&client_serv, len) < 0)
            {
                perror("sendto");
                return FAILURE;
            }

            printf("File data sent. Sending END packet.\n");

            return SUCCESS;
        }

    step1:

        int pkt_size = sizeof(data_var.opcode) +
                       sizeof(data_var.block_no) +
                       ret;

        // Send DATA packet
        int send_len = sendto(sock_fd, &data_var, pkt_size, 0,
                              (struct sockaddr *)&client_serv, len);

        if (send_len < 0)
        {
            perror("sendto");
            return FAILURE;
        }

        printf("DATA block %d sent (%d bytes).\n", no, ret);

        // Wait for ACK
        recv_len = recvfrom(sock_fd, &ack_var, sizeof(ack_var), 0,
                            (struct sockaddr *)&client_serv, &len);

        if (recv_len < 0)
        {
            perror("recvfrom");
            return FAILURE;
        }

        // Validate ACK for the current block
        if (recv_len < sizeof(Ack_pkt) ||
            ntohs(ack_var.opcode) != OPCODE_ACK ||
            ntohs(ack_var.block_no) != no)
        {
            printf("Invalid ACK received for block %d. Retrying.\n", no);
            goto step1;
        }

        printf("ACK %d received successfully.\n", no);

        // Normal mode ends when the last packet contains less than 512 bytes
        if (mode == NORMAL && ret < 512)
        {
            break;
        }

        no++;
    }

    return SUCCESS;
}