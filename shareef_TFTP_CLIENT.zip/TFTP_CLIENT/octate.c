#include "CLIENT.h"

void octate_get_mode()
{
    char file_name[50];

    printf("Enter filename: ");
    scanf(" %[^\n]", file_name);

    // Send RRQ request in Octet mode
    if (sent_request_pkt(file_name, OPCODE_RRQ, OCTATE) == FAILURE)
    {
        printf("Error: Server could not send the file.\n");
        return;
    }

    if (get_file(file_name, OCTATE) == FAILURE)
    {
        printf("Error: GET operation failed.\n");
    }
}

void octate_put_mode()
{
    char file_name[50];

    printf("Enter filename: ");
    scanf(" %[^\n]", file_name);

    int fd = open(file_name, O_RDONLY);

    if (fd == -1)
    {
        printf("Error: File '%s' not found.\n", file_name);
        return;
    }

    // Send WRQ request in Octet mode
    if (sent_request_pkt(file_name, OPCODE_WRQ, OCTATE) == FAILURE)
    {
        printf("Error: Server could not receive the file.\n");
        close(fd);
        return;
    }

    if (put_file(file_name, fd, OCTATE) == FAILURE)
    {
        printf("Error: PUT operation failed.\n");
    }

    close(fd);
}