#include "CLIENT.h"

int sock_fd;
struct sockaddr_in serv;
int connect_flag = 0;


/* Connect to server */

int connect_server()
{
    char ip[50];
    int port;

    printf("Enter the IP address of server: ");

    if (scanf(" %49[^\n]", ip) != 1)
    {
        printf("Invalid IP address.\n");
        while (getchar() != '\n');
        return FAILURE;
    }

    if (validate_ip(ip) == FAILURE)
    {
        printf("Invalid IP address.\n");
        return FAILURE;
    }

    printf("Enter the port number of server: ");

    if (scanf("%d", &port) != 1)
    {
        printf("Invalid port number. Please enter a valid number.\n");
        while (getchar() != '\n');
        return FAILURE;
    }

    if (port < 1 || port > 65535)
    {
        printf("Invalid port number. Enter a value between 1 and 65535.\n");
        return FAILURE;
    }

    // Create UDP socket
    sock_fd = socket(AF_INET, SOCK_DGRAM, 0);

    if (sock_fd == -1)
    {
        perror("socket");
        return FAILURE;
    }

    memset(&serv, 0, sizeof(serv));

    serv.sin_family = AF_INET;
    serv.sin_port = htons(port);
    serv.sin_addr.s_addr = inet_addr(ip);

    Req_pkt req_var;

    memset(&req_var, 0, sizeof(req_var));

    req_var.opcode = htons(OPCODE_CONNECT);

    // Send connection request to the server
    int ret = sendto(sock_fd, &req_var, sizeof(req_var), 0,
                     (struct sockaddr *)&serv, sizeof(serv));

    if (ret < 0)
    {
        perror("sendto");
        close(sock_fd);
        return FAILURE;
    }

    printf("Connection request sent. Waiting for server response...\n");

    char msg[50];

    socklen_t len = sizeof(serv);

    // Wait for server connection response
    ret = recvfrom(sock_fd, msg, sizeof(msg) - 1, 0,
                   (struct sockaddr *)&serv, &len);

    if (ret < 0)
    {
        perror("recvfrom");
        close(sock_fd);
        return FAILURE;
    }

    msg[ret] = '\0';

    printf("Server: %s\n", msg);
    printf("Connected to server successfully.\n");

    connect_flag = 1;

    return SUCCESS;
}


/* Validate IPv4 address */

int validate_ip(char *str)
{
    struct sockaddr_in sa;

    if (inet_pton(AF_INET, str, &(sa.sin_addr)) == 1)
    {
        return SUCCESS;
    }

    return FAILURE;
}


/* Send RRQ / WRQ request */

Status sent_request_pkt(char *filename, int val, int mode)
{
    Req_pkt req_var;

    memset(&req_var, 0, sizeof(req_var));

    req_var.opcode = htons(val);

    strcpy(req_var.file_name, filename);

    req_var.mode = htons(mode);

    // Send the file transfer request
    printf("Sending %s request...\n",
           val == OPCODE_RRQ ? "GET" : "PUT");

    int ret = sendto(sock_fd, &req_var, sizeof(req_var), 0,
                     (struct sockaddr *)&serv, sizeof(serv));

    if (ret < 0)
    {
        perror("sendto");
        return FAILURE;
    }

    printf("Request sent. Waiting for server response...\n");

    return SUCCESS;
}