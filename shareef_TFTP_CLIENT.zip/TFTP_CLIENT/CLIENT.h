#ifndef CLIENT_H
#define CLIENT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>


/* Return status */

typedef enum
{
    SUCCESS,
    FAILURE
} Status;


/* TFTP request packet */

typedef struct req_pkt
{
    unsigned short opcode;
    char file_name[50];
    unsigned short mode;

} Req_pkt;


/* TFTP data packet */

typedef struct data_pkt
{
    unsigned short opcode;
    unsigned short block_no;
    char data[512];

} Data_pkt;


/* TFTP acknowledgement packet */

typedef struct ack_pkt
{
    unsigned short opcode;
    unsigned short block_no;

} Ack_pkt;


/* TFTP error packet */

typedef struct error_pkt
{
    unsigned short opcode;
    unsigned short error_code;
    char error_msg[50];

} Error_pkt;


/* TFTP operation codes */

typedef enum
{
    OPCODE_RRQ = 1,
    OPCODE_WRQ = 2,
    OPCODE_DATA = 3,
    OPCODE_ACK = 4,
    OPCODE_ERROR = 5,

    MODE = 6,
    OPCODE_CONNECT = 7,
    END = 10

} Opcode;


/* File transfer modes */

typedef enum
{
    NORMAL = 8,
    OCTATE = 9,
    NETASCI = 11

} TransferMode;


/* Global variables */

extern int sock_fd;
extern struct sockaddr_in serv;
extern int connect_flag;


/* Connection handling */

int connect_server(void);
int validate_ip(char *str);


/* Request packet handling */

Status sent_request_pkt(char *filename, int val, int mode);


/* Normal mode operations */

int get_mode(void);
Status put_mode(int mode);
Status put_file(char *filename, int fd, int mode);


/* File receiving */

Status get_file(char *file_name, int mode);


/* Mode selection */

void mode(void);
void normal_mode(void);
void octate_mode(void);


/* Octet mode operations */

void octate_get_mode(void);
void octate_put_mode(void);


/* Netascii mode operations */

void netasci_mode(void);
void netasci_get_mode(void);
Status netasci_put_mode(void);
Status netasci_put_file(char *filename, int fd, int mode);

#endif