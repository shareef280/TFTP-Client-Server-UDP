#include "CLIENT.h"

void mode()
{
    while (1)
    {
        int option;

        printf("\n-------- Transfer Mode --------\n");
        printf("1. Normal\n");
        printf("2. Octet\n");
        printf("3. Netascii\n");
        printf("4. Back\n");

        printf("Enter your choice: ");

        if (scanf("%d", &option) != 1)
        {
            printf("Invalid input. Please enter a number from 1 to 4.\n");
            while (getchar() != '\n');
            continue;
        }

        switch (option)
        {
            case 1:
                normal_mode();
                break;

            case 2:
                octate_mode();
                break;

            case 3:
                netasci_mode();
                break;

            case 4:
                printf("Returning to main menu.\n");
                return;

            default:
                printf("Invalid choice. Please select an option from 1 to 4.\n");
        }
    }
}


void normal_mode()
{
    while (1)
    {
        int option;

        printf("\n-------- Normal Mode --------\n");
        printf("1. Get\n");
        printf("2. Put\n");
        printf("3. Back\n");

        printf("Enter your choice: ");

        if (scanf("%d", &option) != 1)
        {
            printf("Invalid input. Please enter a number from 1 to 3.\n");
            while (getchar() != '\n');
            continue;
        }

        switch (option)
        {
            case 1:

                if (connect_flag == 0)
                {
                    printf("Please connect to the server first.\n");
                    break;
                }

                if (get_mode() == FAILURE)
                {
                    printf("GET operation failed.\n");
                }

                break;

            case 2:

                if (connect_flag == 0)
                {
                    printf("Please connect to the server first.\n");
                    break;
                }

                if (put_mode(NORMAL) == FAILURE)
                {
                    printf("PUT operation failed.\n");
                }

                break;

            case 3:

                printf("Returning from Normal mode.\n");
                return;

            default:

                printf("Invalid choice. Please select an option from 1 to 3.\n");
        }
    }
}


void octate_mode()
{
    while (1)
    {
        int option;

        printf("\n-------- Octet Mode --------\n");
        printf("1. Get\n");
        printf("2. Put\n");
        printf("3. Back\n");

        printf("Enter your choice: ");

        if (scanf("%d", &option) != 1)
        {
            printf("Invalid input. Please enter a number from 1 to 3.\n");
            while (getchar() != '\n');
            continue;
        }

        switch (option)
        {
            case 1:

                if (connect_flag == 0)
                {
                    printf("Please connect to the server first.\n");
                    break;
                }

                octate_get_mode();
                break;

            case 2:

                if (connect_flag == 0)
                {
                    printf("Please connect to the server first.\n");
                    break;
                }

                octate_put_mode();
                break;

            case 3:

                printf("Returning from Octet mode.\n");
                return;

            default:

                printf("Invalid choice. Please select an option from 1 to 3.\n");
        }
    }
}


void netasci_mode()
{
    while (1)
    {
        int option;

        printf("\n-------- Netascii Mode --------\n");
        printf("1. Get\n");
        printf("2. Put\n");
        printf("3. Back\n");

        printf("Enter your choice: ");

        if (scanf("%d", &option) != 1)
        {
            printf("Invalid input. Please enter a number from 1 to 3.\n");
            while (getchar() != '\n');
            continue;
        }

        switch (option)
        {
            case 1:

                if (connect_flag == 0)
                {
                    printf("Please connect to the server first.\n");
                    break;
                }

                netasci_get_mode();
                break;

            case 2:

                if (connect_flag == 0)
                {
                    printf("Please connect to the server first.\n");
                    break;
                }

                if (netasci_put_mode() == FAILURE)
                {
                    printf("Netascii PUT operation failed.\n");
                }

                break;

            case 3:

                printf("Returning from Netascii mode.\n");
                return;

            default:

                printf("Invalid choice. Please select an option from 1 to 3.\n");
        }
    }
}