#include "SERVER.H"

void put_file(Req_pkt *req_var, int transfer_sock)
{
    Data_pkt data_var;
    Ack_pkt ack_var;

    // Open the destination file for writing
    int fd = open(req_var->file_name, O_WRONLY | O_CREAT | O_TRUNC, 0644);

    if (fd < 0)
    {
        perror("open");
        return;
    }

    struct sockaddr_in data_client;
    socklen_t data_len = sizeof(data_client);

    // Send ACK 0 to confirm the PUT request
    ack_var.opcode = htons(OPCODE_ACK);
    ack_var.block_no = htons(0);

    if (sendto(transfer_sock, &ack_var, sizeof(ack_var), 0, (struct sockaddr *)&client_serv, sizeof(client_serv)) < 0)
    {
        perror("sendto");
        close(fd);
        return;
    }

    printf("ACK 0 sent - ready to receive file\n");

    while (1)
    {
        data_len = sizeof(data_client);

        // Receive DATA packet from the client
        int ret = recvfrom(transfer_sock, &data_var, sizeof(data_var), 0, (struct sockaddr *)&data_client, &data_len);

        if (ret < 0)
        {
            perror("recvfrom");
            break;
        }

        // Validate the received packet size
        if (ret < sizeof(data_var.opcode) + sizeof(data_var.block_no))
        {
            printf("Error: Invalid DATA packet received\n");
            continue;
        }

        int data_size = ret - sizeof(data_var.opcode) - sizeof(data_var.block_no);

        printf("Received block %d (%d bytes)\n", ntohs(data_var.block_no), data_size);

        // Check for end of file
        if (ntohs(data_var.opcode) == END)
        {
            printf("PUT transfer completed successfully\n");
            break;
        }

        // Accept only DATA packets
        if (ntohs(data_var.opcode) != OPCODE_DATA)
        {
            printf("Error: Invalid opcode received\n");
            continue;
        }

        // Write received data into the file
        if (data_size > 0)
        {
            int w = write(fd, data_var.data, data_size);

            if (w < 0)
            {
                perror("write");
                break;
            }

            printf("Block %d written successfully (%d bytes)\n", ntohs(data_var.block_no), w);
        }

        // Send ACK for the received DATA packet
        ack_var.opcode = htons(OPCODE_ACK);
        ack_var.block_no = data_var.block_no;

        if (sendto(transfer_sock, &ack_var, sizeof(ack_var), 0, (struct sockaddr *)&data_client, data_len) < 0)
        {
            perror("sendto");
            break;
        }

        printf("ACK %d sent to client\n", ntohs(ack_var.block_no));
    }

    close(fd);

    printf("PUT transfer finished\n");
}