#include "SERVER.H"

Status get_file(Req_pkt *var, int transfer_sock)
{
    int fd = open(var->file_name, O_RDONLY);

    if (fd == -1)
    {
        printf("Error: File '%s' not found\n", var->file_name);
        return FAILURE;
    }

    Data_pkt data_var;
    Ack_pkt ack_var;

    char buffer[512];
    int ret;
    int no = 1;
    int pkt_size;

    printf("GET: Sending file '%s'\n", var->file_name);

    while (1)
    {
        // Read 512 bytes in normal mode and 1 byte in octet mode
        if (ntohs(var->mode) == NORMAL)
        {
            ret = read(fd, buffer, 512);
        }
        else if (ntohs(var->mode) == OCTATE)
        {
            ret = read(fd, buffer, 1);
        }
        else
        {
            printf("Error: Invalid transfer mode\n");
            close(fd);
            return FAILURE;
        }

        memset(&data_var, 0, sizeof(data_var));

        data_var.opcode = htons(OPCODE_DATA);
        data_var.block_no = htons(no);

        // Copy file data into the DATA packet
        if (ret > 0)
        {
            memcpy(data_var.data, buffer, ret);
        }

    step1:

        // Calculate the DATA packet size
        pkt_size = sizeof(data_var.opcode) + sizeof(data_var.block_no) + ret;

        // Send END packet when the file has been completely read
        if (ret <= 0)
        {
            data_var.opcode = htons(END);

            sendto(transfer_sock, &data_var, sizeof(data_var.opcode) + sizeof(data_var.block_no), 0, (struct sockaddr *)&client_serv, sizeof(client_serv));

            printf("GET: File transfer completed\n");

            close(fd);
            return SUCCESS;
        }

        // Send DATA packet to the client
        int send_len = sendto(transfer_sock, &data_var, pkt_size, 0, (struct sockaddr *)&client_serv, sizeof(client_serv));

        if (send_len < 0)
        {
            perror("Error: sendto");
            close(fd);
            return FAILURE;
        }

        printf("GET: DATA block %d sent (%d bytes)\n", no, ret);

        // Wait for ACK from the client
        int recv_len = recvfrom(transfer_sock, &ack_var, sizeof(ack_var), 0, (struct sockaddr *)&client_serv, &len);

        if (recv_len < 0)
        {
            perror("Error: recvfrom");
            close(fd);
            return FAILURE;
        }

        // Validate the received ACK
        if (ntohs(ack_var.opcode) != OPCODE_ACK ||
            ntohs(ack_var.block_no) != no)
        {
            printf("GET: Invalid ACK received for block %d, retrying...\n", no);
            goto step1;
        }

        printf("GET: ACK %d received\n", no);

        // Stop after the last short packet in normal mode
        if (ntohs(var->mode) == NORMAL && ret < 512)
        {
            printf("GET: File transfer completed\n");
            break;
        }

        // Move to the next block
        no++;
    }

    close(fd);

    return SUCCESS;
}