#include "SERVER.H"

void mode(Req_pkt *req_var, int transfer_sock)
{
    printf("Request received from client\n");

    // Select the transfer mode requested by the client
    switch (ntohs(req_var->mode))
    {
        case NORMAL:

            printf("Transfer mode: NORMAL\n");

            normal_mode(req_var, transfer_sock);

            break;

        case OCTATE:

            printf("Transfer mode: OCTET\n");

            octate_mode(req_var, transfer_sock);

            break;

        case NETASCI:

            printf("Transfer mode: NETASCII\n");

            netasci_mode(req_var, transfer_sock);

            break;

        default:

            printf("Error: Invalid transfer mode\n");

            break;
    }
}


void normal_mode(Req_pkt *req_var, int transfer_sock)
{
    // Select GET or PUT operation for normal mode
    switch (ntohs(req_var->opcode))
    {
        case OPCODE_RRQ:

            printf("Operation: GET\n");

            get_file(req_var, transfer_sock);

            break;

        case OPCODE_WRQ:

            printf("Operation: PUT\n");

            put_file(req_var, transfer_sock);

            printf("PUT operation completed\n");

            break;

        default:

            printf("Error: Invalid operation code\n");

            break;
    }
}


void octate_mode(Req_pkt *req_var, int transfer_sock)
{
    // Select GET or PUT operation for octet mode
    switch (ntohs(req_var->opcode))
    {
        case OPCODE_RRQ:

            printf("Operation: GET\n");

            get_file(req_var, transfer_sock);

            break;

        case OPCODE_WRQ:

            printf("Operation: PUT\n");

            put_file(req_var, transfer_sock);

            printf("PUT operation completed\n");

            break;

        default:

            printf("Error: Invalid operation code\n");

            break;
    }
}


void netasci_mode(Req_pkt *req_var, int transfer_sock)
{
    // Select GET or PUT operation for netascii mode
    switch (ntohs(req_var->opcode))
    {
        case OPCODE_RRQ:

            printf("Operation: GET\n");

            netasci_get_file(req_var, transfer_sock);

            break;

        case OPCODE_WRQ:

            printf("Operation: PUT\n");

            put_file(req_var, transfer_sock);

            printf("PUT operation completed\n");

            break;

        default:

            printf("Error: Invalid operation code\n");

            break;
    }
}