
/**
 * Project Title : TFTP (Trivial File Transfer Protocol)
 * Author        : Shareef sab
 * Batch         : 26001B(084)
 * Date          : 12/09/2026
 *
 * Description:
 * This project implements a TFTP client-server application using
 * UDP socket programming. It supports file transfer operations such
 * as GET and PUT with different transfer modes including Normal,
 * Octet, and Netascii modes.
 *
 * The client provides a menu-driven interface to connect to the
 * server, transfer files, select transfer modes, and terminate the
 * connection.
 *
 * The server handles client requests using separate processes and
 * performs file transfer through UDP sockets.
 */



#include "SERVER.H"

int sock_fd;
struct sockaddr_in client_serv;
socklen_t len;

int main()
{
    struct sockaddr_in serv;

    // Create UDP socket for client requests
    sock_fd = socket(AF_INET, SOCK_DGRAM, 0);

    if (sock_fd == -1)
    {
        perror("socket");
        return FAILURE;
    }

    memset(&serv, 0, sizeof(serv));

    // Configure server IP address and port
    serv.sin_family = AF_INET;
    serv.sin_port = htons(5500);
    serv.sin_addr.s_addr = inet_addr("10.97.193.142");

    // Bind the socket to the server address
    if (bind(sock_fd, (struct sockaddr *)&serv, sizeof(serv)) == -1)
    {
        perror("bind");
        close(sock_fd);
        return FAILURE;
    }

    printf("TFTP Server started successfully\n");
    printf("Server listening on 10.97.193.142:5500\n");
     printf("\nWaiting for client request...\n");
    while (1)
    {
        Req_pkt req_var;

        len = sizeof(client_serv);

        // Wait for the next client request
        
        fflush(stdout);

        int recv_len = recvfrom(sock_fd, &req_var, sizeof(req_var), 0,
                                (struct sockaddr *)&client_serv, &len);

        if (recv_len < 0)
        {
            perror("recvfrom");
            continue;
        }

        printf("Client request received\n");

        // Create a child process to handle the request
        int pid = fork();

        if (pid < 0)
        {
            perror("fork");
            continue;
        }

        if (pid == 0)
        {
            struct sockaddr_in transfer_addr;

            // Create a separate socket for file transfer
            int transfer_sock = socket(AF_INET, SOCK_DGRAM, 0);

            if (transfer_sock < 0)
            {
                perror("socket");
                exit(1);
            }

            memset(&transfer_addr, 0, sizeof(transfer_addr));

            transfer_addr.sin_family = AF_INET;
            transfer_addr.sin_addr.s_addr = INADDR_ANY;
            transfer_addr.sin_port = htons(0);

            // Bind transfer socket to an available port
            if (bind(transfer_sock, (struct sockaddr *)&transfer_addr,
                     sizeof(transfer_addr)) == -1)
            {
                perror("bind");
                close(transfer_sock);
                exit(1);
            }

            // Handle the requested operation
            switch (ntohs(req_var.opcode))
            {
                case OPCODE_RRQ:

                    printf("GET request received\n");

                    // Use Netascii conversion only for Netascii GET
                    if (ntohs(req_var.mode) == NETASCI)
                    {
                        netasci_get_file(&req_var, transfer_sock);
                    }
                    else
                    {
                        get_file(&req_var, transfer_sock);
                    }

                    break;

                case OPCODE_WRQ:

                    printf("PUT request received\n");

                    // Receive the file from the client
                    put_file(&req_var, transfer_sock);

                    break;

                case MODE:

                    printf("Mode selection request received\n");

                    // Handle the requested transfer mode
                    mode(&req_var, transfer_sock);

                    break;

                case OPCODE_CONNECT:

                    printf("Client connection request received\n");

                    char msg[] = "server connected";

                    // Send connection confirmation to the client
                    sendto(sock_fd, msg, sizeof(msg), 0,
                           (struct sockaddr *)&client_serv, len);

                    printf("Connection established with client\n");

                    break;

                default:

                    printf("Error: Invalid request opcode received\n");

                    break;
            }

            close(transfer_sock);
             printf("\nWaiting for client request...\n");
            // Child process exits after completing the request
            exit(0);
        }

        /*
         * Parent continues waiting for new client requests.
         */
        
    }

    return SUCCESS;
}