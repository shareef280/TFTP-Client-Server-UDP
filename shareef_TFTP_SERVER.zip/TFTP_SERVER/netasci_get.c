#include "SERVER.H"

Status netasci_get_file(Req_pkt *var, int transfer_sock)
{
    int fd = open(var->file_name, O_RDONLY);

    if (fd == -1)
    {
        printf("Error: Unable to open file '%s'\n", var->file_name);
        return FAILURE;
    }

    Data_pkt data_var;
    Ack_pkt ack_var;
    char buffer[512];

    int no = 1;
    int i;
    int eof;

    printf("NETASCII GET: Sending file '%s'\n", var->file_name);

    while (1)
    {
        i = 0;
        eof = 0;

        // Read characters and convert LF to CR-LF
        while (i < 512)
        {
            char ch;

            int ret = read(fd, &ch, 1);

            if (ret == 0)
            {
                eof = 1;
                break;
            }

            if (ret < 0)
            {
                perror("read");
                close(fd);
                return FAILURE;
            }

            if (ch == '\n')
            {
                // Add CR-LF when enough space is available
                if (i <= 510)
                {
                    buffer[i++] = '\r';
                    buffer[i++] = '\n';
                }
                else
                {
                    // Save LF for the next packet
                    buffer[i++] = '\r';
                    break;
                }
            }
            else
            {
                buffer[i++] = ch;
            }
        }

        memset(&data_var, 0, sizeof(data_var));

        data_var.opcode = htons(OPCODE_DATA);
        data_var.block_no = htons(no);

        // Copy converted data into the DATA packet
        if (i > 0)
        {
            memcpy(data_var.data, buffer, i);
        }

        int pkt_size = sizeof(data_var.opcode) + sizeof(data_var.block_no) + i;

        // Send END packet when the file is completely transmitted
        if (i == 0 && eof)
        {
            data_var.opcode = htons(END);

            if (sendto(transfer_sock, &data_var, sizeof(data_var.opcode) + sizeof(data_var.block_no), 0, (struct sockaddr *)&client_serv, sizeof(client_serv)) < 0)
            {
                perror("sendto");
                close(fd);
                return FAILURE;
            }

            printf("NETASCII GET: Transfer completed\n");

            close(fd);
            return SUCCESS;
        }

    step1:

        // Send DATA packet
        if (sendto(transfer_sock, &data_var, pkt_size, 0, (struct sockaddr *)&client_serv, sizeof(client_serv)) < 0)
        {
            perror("sendto");
            close(fd);
            return FAILURE;
        }

        printf("Block %d sent (%d bytes)\n", no, i);

        // Wait for ACK
        int recv_len = recvfrom(transfer_sock, &ack_var, sizeof(ack_var), 0, (struct sockaddr *)&client_serv, &len);

        if (recv_len < 0)
        {
            perror("recvfrom");
            close(fd);
            return FAILURE;
        }

        // Validate ACK
        if (recv_len < sizeof(Ack_pkt) ||
            ntohs(ack_var.opcode) != OPCODE_ACK ||
            ntohs(ack_var.block_no) != no)
        {
            printf("Warning: Invalid ACK received for block %d, retrying\n", no);
            goto step1;
        }

        printf("ACK %d received\n", no);

        // Move to the next DATA block
        no++;
    }

    close(fd);

    return SUCCESS;
}